module.exports=[21490,a=>{"use strict";var b=a.i(22918);a.s([],5973),a.i(5973),a.s(["00841e8abd65e80a6805d24b8a0c30b409dc5de8cf",()=>b.getAboutData],21490)}];

//# sourceMappingURL=_next-internal_server_app_about_page_actions_a5e5a1da.js.map