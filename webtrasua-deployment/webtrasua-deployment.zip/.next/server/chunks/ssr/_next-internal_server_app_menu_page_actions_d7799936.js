module.exports=[7115,a=>{"use strict";var b=a.i(22918);a.s([],90637),a.i(90637),a.s(["0024eccb5e429b6eeb00abdf7a1b092a0f422ba8cf",()=>b.getCategories,"00ea36612f064356975b750148aeffad7251ee7289",()=>b.getDrinks],7115)}];

//# sourceMappingURL=_next-internal_server_app_menu_page_actions_d7799936.js.map